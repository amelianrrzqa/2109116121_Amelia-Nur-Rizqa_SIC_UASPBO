package topiafashion;

public class Topiafashion {
    public static void main(String[] args) {
        flogin start = new flogin();
        start.setVisible(true);
    }
    
}

